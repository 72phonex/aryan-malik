ARYAN MALIK — PERSONAL SYSTEM
==============================

HOW TO RUN
----------
Double-click index.html, or drag it into any browser window.
No server, no build step, no install — it's a single self-contained file
(the two reels are embedded inside it as video data).

OFFLINE FONTS
-------------
The page loads three Google Fonts (Archivo, Inter, JetBrains Mono) over
the network for the exact intended look. With no internet connection,
those requests simply fail and the page falls back to clean system fonts
(Helvetica Neue / Arial / system monospace) — nothing breaks, it just
looks slightly less custom until you're back online. If you want the
exact type with zero network dependency, self-host the three font files
as @font-face rules with base64-encoded woff2 data in the <style> block
near the top of the file, in place of the <link> tags in <head>.

EDITING CONTENT
----------------
Open index.html in a text editor and search for "const DATA = {" — every
piece of copy, every project, every link lives in that one object. Lines
marked with ◆ REPLACE are placeholders that still need your real values:

  - profile.location            your city / timezone, if different
  - socials.email / .github / .linkedin / .x   currently unset —
    unset links render as "— NOT SET" instead of pointing anywhere
  - projects[].links[].href     live URL / source URL per project
  - the two motion-study projects' copy, if they're not self-directed

Nothing else in the file needs to change for these edits to take effect.

PERFORMANCE
-----------
The background field auto-tunes itself: if your device can't sustain a
smooth frame rate for a couple of seconds, it quietly lowers its own
resolution and density (twice, at most) rather than staying stuck slow.
This never reverses mid-session, so a very brief stutter (e.g. switching
tabs) won't visibly change anything, but sustained strain will.

BROWSER SUPPORT
----------------
Any current Chrome, Safari, Firefox or Edge. Falls back to a simpler,
static rendering automatically if the visitor's system has "reduce
motion" turned on, and simplifies further on low-power / small-screen
devices.
